from .evolutionary_tournament import EvolutionaryTournament


class BinaryGA:
    def __init__(self):
        pass